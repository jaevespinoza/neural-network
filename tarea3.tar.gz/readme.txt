https://github.com/jaevespinoza/neural-network

Para ejecutar tarea, usar TicTacToe.py. Lo que hará será entrenar la red y calculara el porcentaje de outputs incorrectos.

Para ejecutar tarea 2, usar Run.py. Se entrenará la red, creado 2 archivos y después leerá estos para poder jugar.

Para ejecutar la clase de genetic algorithms, se debe ejecutar la clase GeneticAlg.

RUT: 19036946-3
